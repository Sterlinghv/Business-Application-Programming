window.addEventListener("load", main)
function main() {
    btbalance.addEventListener("click", calcbalance)
} 
function calcbalance(){

// declare
var principal, interest, duration   // input
var i, r1                           // processing
var total                           // output

// input
principal=parseFloat(txprincipal.value)                   // $10000
interest=parseFloat(txinterest.value)/100                 // 15%
duration=parseFloat(txduration.value)                     // 33 years

// processing
i=1                                 // counter
r1=(1+interest)                     // + interest
total=principal
while (i<=duration) {
    total=total*r1
    i=i+1
}

// output
// console.log("Ending balance is: $"+total.toFixed(2))

sptotal.innerHTML=total.toFixed(2)
}