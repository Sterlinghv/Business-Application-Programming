window.addEventListener("load", main)
function main(){
    btfuturevalue.addEventListener("click", calcfuturevalue)
}
function calcfuturevalue(){


// declare
var cash, rateofreturn, time // input
var i                        // processing
var futurevalue              // output

// input
cash=parseFloat(txcash.value)                   // 1000
rateofreturn=parseFloat(txrateofreturn.value)/100  // 15
time=parseFloat(txtime.value)                   // 10

// processing
i=1
futurevalue=cash
while(i<=time) {
    futurevalue=cash*(1+rateofreturn)**time
    i=i+1
}
// console.log("Future Value is: $" + futurevalue.toFixed(2))
spfuturevalue.innerHTML=futurevalue.toFixed(2)
}