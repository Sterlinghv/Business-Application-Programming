window.addEventListener("load", main)
function main() {
    btbalance.addEventListener("click", calcbalance)
}

function calcbalance () {
// declare
var balance, amount, duration // input
var i                         // processing
var total                     // output

// input
balance=parseFloat(txbalance.value)  // 0
amount=parseFloat(txamount.value)    // 100
duration=parseFloat(txduration.value)// 12

//processing
i=1
total=balance
while (i<=duration) {
    total=total+amount
    i=i+1
}

// output
// console.log("Ending balance is: $"+total.toFixed(2))
sptotal.innerHTML=total.toFixed(2)
}