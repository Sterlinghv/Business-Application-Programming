i=1
while (i<=10) {
    console.log("The value of i is: "+i)
    i=i+1

}
j=0

for (i=1;i<=10;i=i+1) {
    console.log("The value of i is: "+i)
}
j=0

i=1
do {
    console.log("The value of i is: "+1)
    i=i+1
} while (i<=10)
j=0