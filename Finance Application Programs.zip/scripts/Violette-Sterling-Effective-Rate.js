
window.addEventListener("load", main)
function main() {
    btEffectiveRate.addEventListener("click", EffectiveRate)
}

function EffectiveRate(){
// declaring variables
var Principal, Rate, Compoundings, Time // input variables
var EffectiveRate // output variables
//input
Principal = parseFloat(txPrincipal.value)
Compoundings = parseFloat(txCompoundings.value)
Rate = parseFloat(txRate.value)/100
Time = parseFloat(txTime.value)
// processing
EffectiveRate = (1+Rate/Compoundings)**(Compoundings*Time) // effective rate
// output
//console.log("Effective Rate is: $" + EffectiveRate.toFixed(2))
spEffectiveRate.innerHTML=EffectiveRate.toFixed(2)
}