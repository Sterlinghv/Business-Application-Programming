window.addEventListener("load", main)
function main() {
    btFutureValue.addEventListener("click", FutureValue)
}

function FutureValue(){
// declaring variables
var Cash, RateOfReturn, Time // input variables
var FutureValue // output variables
// input
Cash = parseFloat(txCash.value)
RateOfReturn = parseFloat(txRateOfReturn.value)/100
Time = parseFloat(txTime.value)
// processing
FutureValue = Cash * (1+RateOfReturn)**Time // future value
// output
//console.log(" Future Value is: $"+ FutureValue.toFixed(2))
spFutureValue.innerHTML=FutureValue.toFixed(2)
}