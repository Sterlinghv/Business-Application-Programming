window.addEventListener("load", main)
function main() {
    btInvShrinkage.addEventListener("click", InvShrinkage)
}

function InvShrinkage(){
// declaring variables
var RecordedInv, ActualInv // input variables
var InvShrinkage // output variables
// input
RecordedInv = parseFloat(txRecordedInv.value)
ActualInv = parseFloat(txActualInv.value)
// processing
InvShrinkage = (RecordedInv - ActualInv) / RecordedInv * 100 //inventory shrinkage
// output
//console.log("Inventory Shrinkage is: %" + InvShrinkage)
spInvShrinkage.innerHTML=InvShrinkage.toFixed(2)
}