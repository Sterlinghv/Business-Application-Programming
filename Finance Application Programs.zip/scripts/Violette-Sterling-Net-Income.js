window.addEventListener("load", main)
function main() {
    btNetincome.addEventListener("click", Netincome)
}

function Netincome(){
// declaring values
var Revenue, Expenses // input variables
var Netincome // output variables
// input
Revenue = parseFloat(txRevenue.value)
Expenses = parseFloat(txExpenses.value)
// processing
Netincome = Revenue - Expenses //net income
//output
//console.log("Netincome is: $"+Netincome)
spNetincome.innerHTML=Netincome.toFixed(2)

}