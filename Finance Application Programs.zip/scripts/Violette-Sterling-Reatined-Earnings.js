window.addEventListener("load", main)
function main() {
    btRetainedEarnings.addEventListener("click", RetainedEarnings)
}

function RetainedEarnings(){
// declaring variables
var BeginningRE, NetIncome, CashDividends // input variables
var RetainedEarnings // output variables
// input
BeginningRE = parseFloat(txBeginningRE.value)
NetIncome = parseFloat(txNetIncome.value)
CashDividends = parseFloat(txCashDividends.value)
// processing
RetainedEarnings = BeginningRE + NetIncome - CashDividends //retained earnings
// output
//console.log("Retained Earnings is: $" + RetainedEarnings)
spRetainedEarnings.innerHTML=RetainedEarnings.toFixed(2)
}