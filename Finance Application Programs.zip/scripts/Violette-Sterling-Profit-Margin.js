window.addEventListener("load", main)
function main() {
    btProfitMargin.addEventListener("click", ProfitMargin)
}

function ProfitMargin(){
// declaring values
var NetIncome, Sales // input variables
var ProfitMargin // output variables
// input
NetIncome = parseFloat(txNetIncome.value)
Sales = parseFloat(txSales.value)
// processing
ProfitMargin = (NetIncome / Sales) * 100 // profit margin
// output
//console.log("Profit Margin is: $"+ProfitMargin)
spProfitMargin.innerHTML=ProfitMargin.toFixed(2)
}