window.addEventListener("load", main)
function main() {
    btPresentValue.addEventListener("click", PresentValue)
}

function PresentValue(){
// declaring variables
var FutureValue, RateOfReturn, Time // input variables
var PresentValue // output variables
// input
FutureValue = parseFloat(txFutureValue.value)
RateOfReturn = parseFloat(txRateOfReturn.value)
Time = parseFloat(txTime.value)
// processing
PresentValue = FutureValue / (1 + RateOfReturn)**Time //present value
// output
//console.log("Present Value is: $" + PresentValue.toFixed(2))
spPresentValue.innerHTML=PresentValue
}