window.addEventListener("load", main)
function main() {
    btCurrentRatio.addEventListener("click", CurrentRatio)

}
function CurrentRatio(){
// declaring values
var Cash, Assets, Liabilities // input variables
var CurrentRatio // output variables
// input
Cash = parseFloat(txCash.value)
Assets = parseFloat(txAssets.value)
Liabilities = parseFloat(txLiabilities.value)
// processing
CurrentRatio = (Cash + Assets) / Liabilities // current ratio
// output
//console.log("Current Ratio is:" + CurrentRatio)
spCurrentRatio.innerHTML=CurrentRatio
}