window.addEventListener("load", main)
function main() {
    btCostOfGoodsSold.addEventListener("click", CostOfGoodsSold)
}

function CostOfGoodsSold(){
// declaring variables
var BeginningInv, Purchases, EndingInv // input variables
var CostOfGoodsSold //output variables
// input
BeginningInv = parseFloat(txBeginningInv.value)
Purchases = parseFloat(txPurchases.value)
EndingInv = parseFloat(txEndingInv.value)
// processing
CostOfGoodsSold = BeginningInv + Purchases - EndingInv //cost of goods sold
// output
//console.log ("Cost of Goods Sold is: $" + CostOfGoodsSold)
spCostOfGoodsSold.innerHTML=CostOfGoodsSold
}