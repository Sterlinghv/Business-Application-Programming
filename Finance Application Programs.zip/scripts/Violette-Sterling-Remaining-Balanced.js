
window.addEventListener("load", main)
function main() {
    btRemainingBalance.addEventListener("click", RemainingBalance)
}

function RemainingBalance(){
// declaring variables
var AmmountBorrowed, PeriodicInterestRate, NumberOfPaymentsMade, NumberPayments // input variables
var RemainingBalance // output variables
// input
AmmountBorrowed = parseFloat(txAmmountBorrowed.value)
PeriodicInterestRate = parseFloat(txPeriodicInterestRate.value)
NumberPayments = parseFloat(txNumberPayments.value)
RegularPayment = parseFloat(txRegularPayment.value)
NumberOfPaymentsMade = parseFloat(txNumberOfPaymentsMade.value)
// processing
RemainingBalance = RegularPayment * ((1-((1+PeriodicInterestRate)**-(NumberPayments-NumberOfPaymentsMade))) / PeriodicInterestRate) // remaining balance
// output
//console.log("Remaining Balance is: $" + RemainingBalance.toFixed(2))
spRemainingBalance.innerHTML=RemainingBalance.toFixed(2)
}