window.addEventListener("load", main)
function main() {
    btBreakEven.addEventListener("click", BreakEven)
}

function BreakEven() {
// declaring values
var FixedCosts, SalesPrice, VariableCosts // input variables
var BreakEven // output variables
// input
FixedCosts = parseFloat(txFixedCosts.value)
SalesPrice = parseFloat(txSalesPrice.value)
VariableCosts = parseFloat(txVariableCosts.value)
// processing
BreakEven = FixedCosts / (SalesPrice - VariableCosts) //break even
// output
//console.log("Break even is:" + BreakEven +" units")
spBreakEven.innerHTML=BreakEven
}