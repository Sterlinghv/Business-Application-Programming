window.addEventListener("load", main)
function main() {
    btTotal.addEventListener("click", Total)
}

function Total() {
    // declaring variables
    var Price, Taxrate // input variables
    var Total // output variables
    // input
    Price   = parseFloat(txPrice.value)
    Taxrate = parseFloat(txTaxrate.value)/100
    // processing
    Total=Price * (1+Taxrate) 
    // output
    // console.log("Total is: $" +Total.toFixed(2))
    spTotal.innerHTML=Total.toFixed(2)
}