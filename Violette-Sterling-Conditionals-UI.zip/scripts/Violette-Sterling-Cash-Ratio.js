window.addEventListener("load", main)
function main() {
    btCashRatio.addEventListener("click", CashRatio)
}

function CashRatio() {
// declaring values
var Cash, Liabilities // input variables
var CashRatio // output variables
// input
Cash = parseFloat(txCash.value)
Liabilities = parseFloat(txLiabilities.value)
// processing
CashRatio = Cash / Liabilities // cash ratio
// output
//console.log("Cash Ratio is:" + CashRatio.toFixed(2))
spCashRatio.innerHTML=CashRatio
if(CashRatio > 1) {
    spComment.innerHTML="Excellent"
} if(CashRatio >.75 && CashRatio <=1){
    spComment.innerHTML="Good"
} if(CashRatio >.5 && CashRatio<=.75){
    spComment.innerHTML="Fair"
} if(CashRatio <=.5){
    spComment.innerHTML="Needs Improvement"
    }


}