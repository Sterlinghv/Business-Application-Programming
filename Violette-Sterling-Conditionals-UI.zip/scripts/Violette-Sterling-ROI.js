window.addEventListener("load", main)
function main() {
    btReturnOnInvestment.addEventListener("click", ReturnOnInvestment)
}

function ReturnOnInvestment(){
// declaring variables
var InvestmentGain, Investment // input variables
var ReturnOnInvestment // output variables
// input
InvestmentGain = parseFloat(txInvestmentGain.value)
Investment = parseFloat(txInvestment.value)
// processing
ReturnOnInvestment = (InvestmentGain - Investment) / Investment //return on investment
// output
//console.log("Return on Investment is: " + ReturnOnInvestment)
spReturnOnInvestment.innerHTML=ReturnOnInvestment.toFixed(2)
if (ReturnOnInvestment >= 0.15){
    spComment.innerHTML="Invest"
} else {
    spComment.innerHTML="Do Not Invest"
    }
}