window.addEventListener("load", main)
function main() {
    btEquity.addEventListener("click", Equity)
}

function Equity() {
// declaring variables
var Assets, Liabilities // input variables
var Equity // output variables
// input
Assets = parseFloat(txAssets.value)
Liabilities = parseFloat(txLiabilities.value)
// processing
Equity = Assets - Liabilities // equity
// output
//console.log("Equity is: $" + Equity)
spEquity.innerHTML=Equity.toFixed(2)
if(Equity > 0) {
    spComment.innerHTML="Healthy"
} else {
    spComment.innerHTML="Unhealthy"
    }
}