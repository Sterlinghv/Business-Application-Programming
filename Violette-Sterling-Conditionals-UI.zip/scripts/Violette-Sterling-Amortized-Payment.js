window.addEventListener("load", main)
function main() {
    btAmortizedLoan.addEventListener("click", AmortizedLoan)
}

function AmortizedLoan(){
// declaring variables
var AmmountBorrowed, PeriodicInterestRate, NumberPayments // input variables
var AmortizedLoan // output variables
// input
AmmountBorrowed = parseFloat(txAmmountBorrowed.value)
PeriodicInterestRate = parseFloat(txPeriodicInterestRate.value)/100
NumberPayments = parseFloat(txNumberPayments.value)
// processing
AmortizedLoan = (AmmountBorrowed * PeriodicInterestRate) / (1 -((1+PeriodicInterestRate)**-NumberPayments)) // amortized loan
// output
//console.log("Amortized Loan Payment is: $" + AmortizedLoan.toFixed(2))
spAmortizedLoan.innerHTML=AmortizedLoan
if (AmortizedLoan < 1000){
    spComment.innerHTML="Very Affordable"
} else if (AmortizedLoan >= 1000 && AmortizedLoan <= 2000){
    spComment.innerHTML="Affordable"
} else if (AmortizedLoan > 2000){
    spComment.innerHTML="Expensive"
    }
}