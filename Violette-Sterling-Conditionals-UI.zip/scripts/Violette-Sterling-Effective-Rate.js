
window.addEventListener("load", main)
function main() {
    btEffectiveRate.addEventListener("click", EffectiveRate)
}

function EffectiveRate(){
// declaring variables
var Principal, Rate, Compoundings, Time // input variables
var EffectiveRate // output variables
//input
Principal = parseFloat(txPrincipal.value)
Compoundings = parseFloat(txCompoundings.value)
Rate = parseFloat(txRate.value)/100
// processing
EffectiveRate = (1+Rate/Compoundings)**(Compoundings)-1 // effective rate
// output
//console.log("Effective Rate is: $" + EffectiveRate.toFixed(2))
spEffectiveRate.innerHTML=EffectiveRate.toFixed(2)
if (EffectiveRate > 0.01+Rate){
    spComment.innerHTML="Over 1% More"
} else {
    spComment.innerHTML="Similar"
    }
}