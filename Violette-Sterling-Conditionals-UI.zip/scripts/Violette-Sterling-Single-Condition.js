assets=200
debts=500
equity=assets-debts

if (equity>0) {
    console.log("Healthy Company!")
} else {
    console.log("Unhealthy Company!")
}

//<, >, ==, != types of conditions