window.addEventListener("load", main)
function main() {
    btProfitMargin.addEventListener("click", ProfitMargin)
}

function ProfitMargin(){
// declaring values
var NetIncome, Sales // input variables
var ProfitMargin // output variables
// input
NetIncome = parseFloat(txNetIncome.value)
Sales = parseFloat(txSales.value)
// processing
ProfitMargin = (NetIncome / Sales) * 100 // profit margin
// output
//console.log("Profit Margin is: $"+ProfitMargin)
spProfitMargin.innerHTML=ProfitMargin.toFixed(2)
if(ProfitMargin > 100.000){
    spComment.innerHTML="Excellent"
} else if(ProfitMargin > 50.00 && ProfitMarin <= 100.000){
    spComment.innerHTML="Good"
} else if(ProfitMargin > 25.00 && ProfitMargin <= 50.00){
    spComment.innerHTML="Fair"
} else {
    spComment.innerHTML="Needs Improvement"
    }
}