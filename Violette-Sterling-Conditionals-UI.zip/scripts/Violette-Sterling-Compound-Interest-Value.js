window.addEventListener("load", main)
function main() {
    btAmmount.addEventListener("click", Ammount)
}

function Ammount(){
// declaring variables
var Principal, Rate, Compoundings, Time // input variables
var Ammount // output variables
//input
Principal = parseFloat(txPrincipal.value)
Compoundings = parseFloat(txCompoundings.value)
Rate = parseFloat(txRate.value)/100
Time = parseFloat(txTime.value)
// processing
Ammount = Principal * (1 + Rate/Compoundings)**(Compoundings * Time) // ammount
// output
//console.log("Compound Interest is: $" + Ammount.toFixed(2))
spAmmount.innerHTML=Ammount
if (Ammount > 4*Principal){
    spComment.innerHTML="Superb"
} else if (Ammount > 3*Principal && Ammount <=4*Principal){
    spComment.innerHTML="Excellent"
} else if (Ammount > 2*Principal && Ammount <=3*Principal){
    spComment.innerHTML="Good"
} else {
    spComment.innerHTML="Keep Saving"
    }
}