window.addEventListener("load", main)
function main() {
    btMarkup.addEventListener("click", Markup)
}

function Markup(){
// declaring values
var PriceOfGoodsSold, CostOfGoodsSold // input variables
var Markup // output variables
// input
PriceOfGoodsSold = parseFloat(txPriceOfGoodsSold.value)
CostOfGoodsSold = parseFloat(txCostOfGoodsSold.value)
// processing
Markup = (PriceOfGoodsSold - CostOfGoodsSold) / CostOfGoodsSold * 100 // markup
// output
//console.log("Markup is: %" + Markup)
spMarkup.innerHTML=Markup.toFixed(2)
if (Markup > 100.00){
    spComment.innerHTML="High"
} else if (Markup > 50.00 && Markup <= 100.00){
    spComment.innerHTML="Medium"
} else if (Markup > 25.00 && Markup <= 50.00){
    spComment.innerHTML="Low"
} else {
    spComment.innerHTML="Too Low"
    }
}