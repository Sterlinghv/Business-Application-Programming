assets=400
debts=500
cash=400
equity=assets-debts
cratio=cash/debts

// if equity > 0 and cratio > .75
if (equity>0 && cratio>.75) {
console.log("Exellent Health")
} else if (equity > 0 && cratio >.5 && cratio <=.75){
// if equity > 0 and cratio is between .5 and .75 
console.log("Good Health")
} else if (equity > 0) {
// otherwise
console.log("Fair Health")
} else {
console.log("Bad Health")
}
// good health if equity > 0 or cratio > .75

if (equity > 0 || cratio > .75) {
    console.log("Good Health")
}
else {
    console.log("Bad Health")
}