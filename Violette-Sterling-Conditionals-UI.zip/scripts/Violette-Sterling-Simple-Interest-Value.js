window.addEventListener("load", main)
function main() {
    btSimpleInterest.addEventListener("click", SimpleInterest)
}

function SimpleInterest(){
// declaring variables
var Principal, Rate, Time // input variables
var SimpleInterest // output variables
//input
Principal = parseFloat(txPrincipal.value)
Rate = parseFloat(txRate.value)/100
Time = parseFloat(txTime.value)
// processing
SimpleInterest = Principal * Rate * Time //simple interest
// output
//console.log("Simple Interest is: $" + SimpleInterest)
spSimpleInterest.innerHTML=SimpleInterest.toFixed(2)
if (SimpleInterest > 2*Principal){
    spComment.innerHTML="You have more than doubled your money!"
} else {
    spComment.innerHTML="Keep Saving"
    }
}
