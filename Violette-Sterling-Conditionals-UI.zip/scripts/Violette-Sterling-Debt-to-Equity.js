window.addEventListener("load", main)
function main() {
    btDebtToEquity.addEventListener("click", DebtToEquity)
}

function DebtToEquity() {
// declaring varibles
var TotalEquity, TotalLiabilities // input variables
var DebtToEquity // output variables
// input
TotalEquity = parseFloat(txTotalEquity.value)
TotalLiabilities = parseFloat(txTotalLiabilities.value)
// processing
DebtToEquity = TotalLiabilities / TotalEquity // debt to equity
// output
//console.log("Debt to Equity is: " + DebtToEquity)
spDebtToEquity.innerHTML=DebtToEquity
if (DebtToEquity > 1){
    spComment.innerHTML="High"
} else if (DebtToEquity > .5 && DebtToEquity <= 1){
    spComment.innerHTML="Average"
} else {
    spComment.innerHTML="Low"
    }
}